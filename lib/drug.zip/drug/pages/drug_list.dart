import 'package:drug_reminder/drug/pages/drug_edit.dart';
import 'package:drug_reminder/drug/services/drug_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DrugListPage extends StatelessWidget {
  const DrugListPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('List Dosis Obat'),
            Expanded(
              child: Consumer<DrugService>(
                builder: (context, drug, _) => ListView.builder(
                  itemCount: drug.listDrug.length,
                  itemBuilder: ((context, index) {
                    return GestureDetector(
                      onTap: () {
                        drug.selectectedIndex = index;
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DrugEditPage()));
                      },
                      child: Container(
                        color: Colors.cyan[50],
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(drug.listDrug[index]['nama']),
                            ),
                            Text(drug.listDrug[index]['dosis'].toString())
                          ],
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
