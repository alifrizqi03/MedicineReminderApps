import 'package:flutter/material.dart';
import 'package:drug_reminder/drug/services/drug_service.dart';
import 'package:provider/provider.dart';

class DrugEditPage extends StatefulWidget {
  const DrugEditPage({Key? key}) : super(key: key);

  @override
  State<DrugEditPage> createState() => _DrugEditPageState();
}

class _DrugEditPageState extends State<DrugEditPage> {
  final TextEditingController dosisBaruController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Consumer<DrugService>(
            builder: (context, drug, child) => Column(
                  children: [
                    Text(drug.listDrug[drug.selectectedIndex!]['nama']),
                    const SizedBox(
                      height: 20,
                    ),
                    const Text('Input Dosis Baru'),
                    TextFormField(
                      controller: dosisBaruController,
                      keyboardType: TextInputType.number,
                    ),
                    TextButton(
                      onPressed: () {
                        drug.updateDosis(drug.selectectedIndex!,
                            int.parse(dosisBaruController.text));
                        Navigator.pop(context);
                      },
                      child: const Text('Save'),
                    )
                  ],
                )),
      ),
    );
  }
}
