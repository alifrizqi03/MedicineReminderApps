import 'package:flutter/material.dart';

class DrugService extends ChangeNotifier {
  int? selectectedIndex;
  List<Map<String, dynamic>> listDrug = [
    {
      'nama': 'Tremenza',
      'dosis': 0,
    },
    {
      'nama': 'amoksisilin',
      'dosis': 0,
    },
  ];

  void updateDosis(int index, int dosis) {
    List<Map<String, dynamic>> listTemp = [];
    for (var i = 0; i < listDrug.length; i++) {
      if (i == index) {
        listTemp.add({
          'nama': listDrug[i]['nama'],
          'dosis': dosis,
        });
        continue;
      }
      listTemp.add(listDrug[i]);
    }
    listDrug = listTemp;
    notifyListeners();
  }
}
